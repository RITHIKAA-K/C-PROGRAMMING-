#include <stdio.h>
#include <conio.h>
int main()
{
    int a=10,b=11;
    printf("%d",a+b);
    printf(" \n%d",a-b);
    printf(" \n%d",a*b);
    printf(" \n%d",a/b);
    printf(" \n%d",a%b);
    return 0;
}