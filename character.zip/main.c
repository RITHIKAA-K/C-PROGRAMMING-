#include <stdio.h>
#include <conio.h>
int main()
{
    char a='e';
    printf("%c",a);
    getch();
}