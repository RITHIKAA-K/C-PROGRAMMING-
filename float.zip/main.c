#include <stdio.h>
#include <conio.h>
int main()
{
    float  b=10.5;
    printf("%f",b);
    
    getch();
    
}