#include <stdio.h>
#include <conio.h>
int main ()
{
    int a=10;
    printf("%d",a);
    float b=10.6;
    printf("    %lf",b);
    getch ();
}
