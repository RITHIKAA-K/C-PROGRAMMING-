#include <stdio.h>
#include <conio.h>
int main ()
{
    int a=10;
    a=15;
    printf("%d",a);
    getch();
}