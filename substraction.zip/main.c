
#include <stdio.h>

int main()
{
    int a=10;
    int b=12;
    int c=b-a;
    printf("%d",c);

    return 0;
}
