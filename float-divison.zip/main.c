
#include <stdio.h>

int main()
{
    float a=12;
    float b=10;
    float c=a/b;
    printf("%lf",c);

    return 0;
}
