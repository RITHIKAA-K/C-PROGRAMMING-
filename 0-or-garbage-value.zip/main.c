
#include <stdio.h>

int main()
{
    int a;
    printf("%d",a);

    return 0;
}
