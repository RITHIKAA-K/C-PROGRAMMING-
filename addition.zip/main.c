
#include <stdio.h>

int main()
{
   int a=10;
   int b =5;
   int sum;
   sum= a+b;
   printf("%d",sum);

    return 0;
}
