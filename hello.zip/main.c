#include <stdio.h>
#include <conio.h>
int main ()
{
    printf("hello");
    getch();
    
}